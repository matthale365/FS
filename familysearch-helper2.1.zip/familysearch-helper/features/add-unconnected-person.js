// features/add-unconnected-person.js
// When the "recents" dropdown opens on a FamilySearch tree page, put a large
// "+ ADD UNCONNECTED PERSON" button near the top so you don't have to scroll
// down to find FamilySearch's own button.
//
// Our button doesn't do anything by itself. It just clicks FamilySearch's real
// button, so FamilySearch keeps doing the actual work.

FSH.features.push({
  name: 'addUnconnectedPerson',

  // FamilySearch's own names for the elements we use. If FamilySearch changes
  // them, this is the only place that needs updating.
  selectors: {
    list: '[data-testid="recents-list"]',
    realButton: '[data-testid="add-unconnected-person"]'
  },

  start() {
    FSH.watch(this.selectors.list, (list) => this.addButton(list));
  },

  addButton(list) {
    if (list.querySelector('.fsh-add-person')) return; // already added

    const wrapper = document.createElement('div');
    wrapper.className = 'fsh-add-person';
    wrapper.setAttribute('data-fsh-ui', '');

    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = '+ ADD UNCONNECTED PERSON';
    button.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      // Find the real button at click time, so we always click the current one.
      const real = list.querySelector(this.selectors.realButton) ||
                   document.querySelector(this.selectors.realButton);
      if (real) {
        real.click();
      } else {
        console.warn('[FS Helper] Could not find FamilySearch\'s Add Unconnected Person button.');
      }
    });

    wrapper.appendChild(button);

    // Put it right after the first row of the list (the search bar).
    const first = list.firstElementChild;
    if (first) first.after(wrapper);
    else list.prepend(wrapper);
  }
});
