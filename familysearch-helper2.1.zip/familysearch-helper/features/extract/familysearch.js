// features/extract/familysearch.js
// Reads a FamilySearch record page (like a NUMIDENT record). The details are a
// table: a label on the left ("Name", "Sex", "Birth Date"...) and the value in
// bold on the right. Rows are found by their label text, not by FamilySearch's
// auto-generated style names, so small site updates shouldn't break it.

FSH.extract.site = {
  name: 'familysearch',

  // Which labels we keep, and the field each one goes into. Labels are
  // compared in lowercase with spaces removed, so "Birth Date" -> "birthdate".
  // Anything else on the record (Alias, Race, Residence Place...) is ignored.
  labels: {
    name: 'fullName',
    sex: 'sex',
    birthdate: 'birthDate',
    birthplace: 'birthPlace',
    deathdate: 'deathDate',
    deathplace: 'deathPlace'
  },

  isRecordPage() {
    return location.pathname.startsWith('/ark:/');
  },

  // e.g. "/ark:/61903/1:1:6KM3-VV1K" (the ?lang=en part is dropped)
  recordId() {
    return location.pathname;
  },

  // Returns the fields, or null if the details table isn't on the page yet.
  read() {
    const key = (text) => text.toLowerCase().replace(/[^a-z]/g, '');

    // Find the details table: the first one with a "Name" row.
    const nameHeader = Array.from(document.querySelectorAll('tr > th'))
      .find((th) => key(th.textContent) === 'name');
    if (!nameHeader) return null;
    const table = nameHeader.closest('tbody, table');

    const raw = {};
    for (const row of table.querySelectorAll('tr')) {
      const th = row.querySelector(':scope > th');
      const td = row.querySelector(':scope > td');
      if (!th || !td) continue;

      const field = this.labels[key(th.textContent)];
      if (!field || raw[field]) continue; // not wanted, or already have it

      // The value is the first bold text. Edited fields also hold a hidden
      // "edit history" copy that isn't bold, so this skips it.
      const value = td.querySelector('strong');
      raw[field] = value ? value.textContent : '';
    }

    return raw;
  }
};