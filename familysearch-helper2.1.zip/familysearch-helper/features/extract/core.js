// features/extract/core.js
// The shared part of extraction. Each site has its own small file that only
// knows how to read that site's page (see familysearch.js). This file does
// everything else, the same way for every site:
//   - decides when to extract (once per record, as soon as its details load)
//   - cleans up the data (names, sex, extra spaces)
//   - refuses to save a record with no name
//   - sends it to background.js to be saved in the list
//   - shows the bottom-right notification
//   - answers the popup's "Extract this page" button
//
// A site file sets FSH.extract.site to an object with:
//   isRecordPage()  true if this page is a record we can extract from
//   recordId()      a unique id for the record (used to avoid duplicates)
//   read()          returns the raw fields, or null if the details aren't loaded yet:
//                   { fullName, sex, birthDate, birthPlace, deathDate, deathPlace }
//                   A site that already knows which part is the last name can
//                   send { given, surname, marriedSurname } instead of fullName.

window.FSH = window.FSH || { features: [] };

FSH.extract = {
  site: null,
  GIVE_UP_AFTER_MS: 20000, // warn if a record's details never show up

  // Turn raw page text into a clean person. Returns null if there's no name.
  clean(raw, site) {
    const tidy = (s) => (s || '').replace(/\s+/g, ' ').trim();
    // ALL-CAPS names become Title Case (JOHN SMITH -> John Smith).
    const fixCaps = (s) => (s && s === s.toUpperCase()
      ? s.toLowerCase().replace(/(^|[\s'-])\p{L}/gu, (m) => m.toUpperCase())
      : s);

    let given, surname, suffix = '';
    if (raw.surname !== undefined) {
      // The site already split the name (e.g. Find a Grave's maiden name).
      given = fixCaps(tidy(raw.given));
      surname = fixCaps(tidy(raw.surname));
    } else {
      // Split into given names / surname, keeping suffixes like Jr. out of the surname.
      const parts = fixCaps(tidy(raw.fullName)).split(' ').filter(Boolean);
      if (parts.length > 2 && /^(jr|sr|ii|iii|iv|v)\.?$/i.test(parts[parts.length - 1])) {
        suffix = parts.pop();
      }
      surname = parts.length > 1 ? parts.pop() : '';
      given = parts.join(' ');
    }

    const fullName = [given, surname, suffix].filter(Boolean).join(' ');
    if (!fullName) return null;

    const sexText = tidy(raw.sex).toLowerCase();
    const sex = sexText === 'male' ? 'Male' : sexText === 'female' ? 'Female' : '';

    return {
      id: site.recordId(),
      source: site.name,
      url: location.href,
      fullName,
      given,
      surname,
      suffix,
      marriedSurname: fixCaps(tidy(raw.marriedSurname)), // for display only, never filled
      sex,
      birthDate: tidy(raw.birthDate),
      birthPlace: tidy(raw.birthPlace),
      deathDate: tidy(raw.deathDate),
      deathPlace: tidy(raw.deathPlace),
      savedAt: Date.now()
    };
  },

  // "1915–2006", "b. 1915", "d. 2006" or "" for the notification and popup.
  years(person) {
    const year = (d) => (d.match(/\d{4}/g) || []).pop() || '';
    const b = year(person.birthDate);
    const d = year(person.deathDate);
    if (b && d) return `${b}–${d}`;
    if (b) return `b. ${b}`;
    if (d) return `d. ${d}`;
    return '';
  },

  // "Sarah Louisa Bridges (married Hussey) · 1839–1921" for notifications.
  label(person) {
    const years = this.years(person);
    return person.fullName +
      (person.marriedSurname ? ` (married ${person.marriedSurname})` : '') +
      (years ? ` · ${years}` : '');
  },

  // Read the page and save. Returns { ok, message } for the popup.
  async run() {
    const site = this.site;
    if (!site || !site.isRecordPage()) {
      return { ok: false, message: 'This page isn\'t a record page.' };
    }

    const raw = site.read();
    if (!raw) {
      return { ok: false, message: 'Record details haven\'t loaded yet. Try again in a moment.' };
    }

    const person = this.clean(raw, site);
    if (!person) {
      FSH.toast('⚠ Couldn\'t find a name on this record, so nothing was saved.', 'warning');
      return { ok: false, message: 'No name found on this record. Nothing saved.' };
    }

    let result;
    try {
      result = await chrome.runtime.sendMessage({ type: 'savePerson', person });
    } catch (err) {
      // Happens if the extension was reloaded while this tab stayed open.
      FSH.toast('⚠ Couldn\'t save. Refresh this page and try again.', 'warning');
      return { ok: false, message: 'Couldn\'t save. Refresh the page and try again.' };
    }
    if (!result || result.status === 'error') {
      FSH.toast('⚠ Couldn\'t save this record.', 'warning');
      return { ok: false, message: 'Couldn\'t save this record.' };
    }

    const label = this.label(person);
    if (result.status === 'updated') {
      FSH.toast(`↻ Already saved, moved to top: ${label}`, 'info');
    } else {
      FSH.toast(`✓ Saved: ${label}`);
    }
    return { ok: true, message: `Saved ${label}` };
  }
};

FSH.features.push({
  name: 'extract',

  doneId: null,     // record already extracted on this page
  waitingFor: null, // record we're waiting on
  waitStarted: 0,
  giveUpTimer: null,
  retryTimer: null,

  start() {
    if (!FSH.extract.site) return; // no extractor for this site

    // Popup's "Extract this page" button. Always runs, even if already done.
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type !== 'extractNow') return;
      FSH.extract.run().then(sendResponse);
      return true;
    });

    // Automatic: once per record, as soon as its details have loaded.
    // This only runs when the page changes, not when you switch back to a
    // tab, so an old tab can't quietly re-save its person.
    FSH.onDomChange(() => this.check());
    this.check();
  },

  check() {
    const site = FSH.extract.site;
    if (!site.isRecordPage()) return;

    const id = site.recordId();
    if (id === this.doneId) return;

    // New record: start the "never loaded" timer.
    if (id !== this.waitingFor) {
      this.waitingFor = id;
      this.waitStarted = Date.now();
      clearTimeout(this.giveUpTimer);
      this.giveUpTimer = setTimeout(() => {
        if (this.doneId !== id && site.recordId() === id) {
          FSH.toast('⚠ Couldn\'t read this record\'s details. Use "Extract this page" in the extension popup.', 'warning');
        }
      }, FSH.extract.GIVE_UP_AFTER_MS);
    }

    // Details not loaded yet: check again shortly (and on the next page change),
    // until they load or the "couldn't read" warning time is up.
    clearTimeout(this.retryTimer);
    if (!site.read()) {
      if (Date.now() - this.waitStarted < FSH.extract.GIVE_UP_AFTER_MS) {
        this.retryTimer = setTimeout(() => this.check(), 500);
      }
      return;
    }

    this.doneId = id;
    clearTimeout(this.giveUpTimer);
    FSH.extract.run();
  }
});