// features/extract/findagrave.js
// Reads a Find a Grave memorial page. Find a Grave labels each piece with a
// fixed id (bio-name, birthDateLabel, deathLocationLabel...), so this is
// simple. Burial, plot and memorial ID are ignored. Find a Grave doesn't
// record sex, so that's left blank for you to choose in the form.
//
// Maiden names: Find a Grave shows a woman's maiden name in italics, e.g.
// "Sarah Louisa <i>Bridges</i> Hussey". FamilySearch wants women under their
// maiden name, so the italic name becomes the last name ("Sarah Louisa" /
// "Bridges"). The married name after it ("Hussey") is kept only so the
// notification and lists can show it; it is never filled into the form.

FSH.extract.site = {
  name: 'findagrave',

  isRecordPage() {
    return /^\/memorial\/\d+/.test(location.pathname);
  },

  // e.g. "findagrave:16833456" (the memorial number)
  recordId() {
    return 'findagrave:' + location.pathname.match(/^\/memorial\/(\d+)/)[1];
  },

  read() {
    const heading = document.querySelector('#bio-name');
    if (!heading) return null;

    const text = (selector) => {
      const el = document.querySelector(selector);
      return el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
    };

    // Dates: drop "(aged 82)", and treat "Unknown" as blank.
    const cleanDate = (d) => {
      const date = d.replace(/\s*\(aged[^)]*\)\s*$/i, '').trim();
      return /^unknown$/i.test(date) ? '' : date;
    };

    return {
      ...this.readName(heading),
      birthDate: cleanDate(text('#birthDateLabel')),
      birthPlace: text('#birthLocationLabel'),
      deathDate: cleanDate(text('#deathDateLabel')),
      deathPlace: text('#deathLocationLabel')
    };
  },

  readName(heading) {
    const name = heading.cloneNode(true);
    // Remove badges/icons Find a Grave adds to some names (e.g. veteran, famous).
    name.querySelectorAll('b, .visually-hidden, img, svg').forEach((el) => el.remove());

    // Mark the italic maiden name so we can split around it.
    const maiden = name.querySelector('i, em');
    if (maiden) maiden.replaceWith('\u0001' + maiden.textContent + '\u0002');

    // Drop nicknames in quotes: William "Bill" Smith -> William Smith.
    const full = name.textContent
      .replace(/"[^"]*"|“[^”]*”/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (!maiden) return { fullName: full.replace(/[\u0001\u0002]/g, '') };

    const [before, rest] = full.split('\u0001');
    const [maidenName, after] = (rest || '').split('\u0002');
    return {
      given: before,
      surname: maidenName,
      marriedSurname: after || ''
    };
  }
};