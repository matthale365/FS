// features/fill-form.js
// Adds a "Fill from saved" button next to the title of two FamilySearch
// popups. Clicking it lists your saved people; picking one fills the popup.
//
//   "Add Unconnected Person" form: fills everything (names, sex, deceased,
//                                  dates, places).
//   "Alternate Name" popup:        fills only the name (first, last, suffix)
//                                  with the saved name, for you to edit into
//                                  the alternate name.
//
// Auto Fill (off by default, switched on in the popup): when either popup
// opens, it's filled with the most recent saved person. Only once per popup,
// and only if no name has been typed in yet.

FSH.features.push({
  name: 'fillForm',

  // FamilySearch's own names for the elements we use. If FamilySearch changes
  // them, this is the only place that needs updating.
  selectors: {
    titleGroup: '[data-overlay-header]',
    firstName: 'input[data-testid="first-name"]',
    lastName: 'input[data-testid="last-name"]',
    suffix: 'input[data-testid="suffix"]',
    sex: 'input[type="radio"][name="sex"]',
    status: 'input[type="radio"][name="status"]',
    birthDate: 'input[name="birthDate"]',
    birthPlace: 'input[name="birthPlace"]',
    deathDate: 'input[name="deathDate"]',
    deathPlace: 'input[name="deathPlace"]'
  },

  // The popups that get a Fill button.
  //   container: the popup itself
  //   isThisKind: extra check (the Alternate Name popup shares its container
  //               with FamilySearch's other "edit a fact" popups)
  //   namesOnly:  fill just the name fields
  kinds: [
    {
      name: 'addPerson',
      container: '[data-testid="add-find-flow"]',
      isThisKind: () => true,
      namesOnly: false
    },
    {
      name: 'alternateName',
      container: '[data-testid="conclusion-dialog"]',
      isThisKind: (popup) => popup.querySelector('.ALTERNATE_NAME') !== null,
      namesOnly: true
    }
  ],

  // Dates: after typing, pick FamilySearch's standardized date from the
  // suggestion list. FamilySearch's list shows what you typed first (no icon),
  // then the standardized date(s) with a calendar icon. We pick the one with
  // the icon, then check the field shows the calendar icon too (has-icon),
  // which means FamilySearch accepted it. If not, we clear it and try again.
  // Places: typed in as-is. Set this to true to also pick the first place
  // suggestion automatically.
  PICK_PLACE_SUGGESTION: false,
  SUGGESTION_WAIT_MS: 4000,
  DATE_ATTEMPTS: 4,

  busy: false,              // true while a fill is running
  autoFilled: new WeakSet(), // popups Auto Fill has already handled

  start() {
    for (const kind of this.kinds) {
      FSH.watch(kind.container, (popup) => this.addButton(popup, kind));
    }
    // Popups can finish loading after they appear, and FamilySearch may redraw
    // the header and remove our button, so check again whenever the page changes.
    FSH.onDomChange(() => {
      for (const kind of this.kinds) {
        document.querySelectorAll(kind.container).forEach((popup) => this.addButton(popup, kind));
      }
    });
  },

  // ---------- The button and person picker ----------

  addButton(popup, kind) {
    if (popup.querySelector('.fsh-fill')) return;
    if (!kind.isThisKind(popup)) return;
    const titleGroup = popup.querySelector(this.selectors.titleGroup);
    if (!titleGroup || !titleGroup.parentElement) return;

    const wrapper = document.createElement('div');
    wrapper.className = 'fsh-fill';
    wrapper.setAttribute('data-fsh-ui', '');

    // The header is also the handle for dragging the window. Stop our clicks
    // from reaching it so pressing the button doesn't start a drag.
    for (const type of ['pointerdown', 'mousedown', 'touchstart', 'keydown']) {
      wrapper.addEventListener(type, (e) => e.stopPropagation());
    }

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'fsh-fill-button';
    button.textContent = 'Fill from saved ▾';
    button.setAttribute('aria-haspopup', 'true');
    button.setAttribute('aria-expanded', 'false');

    const menu = document.createElement('div');
    menu.className = 'fsh-fill-menu';
    menu.hidden = true;

    button.addEventListener('click', () => {
      if (menu.hidden) this.openMenu(popup, kind, button, menu);
      else this.closeMenu(button, menu);
    });

    wrapper.append(button, menu);
    // Right after the title, in the same row.
    titleGroup.parentElement.after(wrapper);

    this.maybeAutoFill(popup, kind);
  },

  // ---------- Auto Fill ----------

  async maybeAutoFill(popup, kind) {
    if (!FSH.settings.get('autoFill') || this.autoFilled.has(popup)) return;
    this.autoFilled.add(popup); // only ever once per popup

    // Give the popup up to 3 seconds to show its name fields.
    for (let i = 0; i < 30 && !popup.querySelector(this.selectors.firstName); i++) {
      await this.wait(100);
    }
    // Let the popup settle first: when editing, FamilySearch may put the
    // existing name into the fields a moment after they appear.
    await this.wait(500);

    const first = popup.querySelector(this.selectors.firstName);
    const last = popup.querySelector(this.selectors.lastName);
    if (!first || !last) return;          // e.g. on the "By ID Number" tab
    if (first.value || last.value) return; // a name is already there (typed, or editing)

    let people = [];
    try {
      people = await chrome.runtime.sendMessage({ type: 'getSavedPeople' });
    } catch (err) {
      return;
    }
    if (!people || people.length === 0) {
      FSH.toast('Auto Fill: no saved people yet. Open a record first.', 'info');
      return;
    }

    this.fill(popup, kind, people[0], { auto: true });
  },

  async openMenu(popup, kind, button, menu) {
    let people = [];
    try {
      people = await chrome.runtime.sendMessage({ type: 'getSavedPeople' });
    } catch (err) {
      FSH.toast('⚠ Couldn\'t load saved people. Refresh this page and try again.', 'warning');
      return;
    }

    menu.textContent = '';
    if (!people || people.length === 0) {
      const empty = document.createElement('p');
      empty.className = 'fsh-fill-empty';
      empty.textContent = 'No saved people yet. Open a record first and it will be saved.';
      menu.appendChild(empty);
    }

    for (const person of people || []) {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'fsh-fill-item';

      const name = document.createElement('span');
      name.className = 'fsh-fill-name';
      name.textContent = person.fullName;

      const details = document.createElement('span');
      details.className = 'fsh-fill-details';
      details.textContent = [
        FSH.extract.years(person),
        person.marriedSurname ? `married ${person.marriedSurname}` : '',
        person.birthPlace
      ].filter(Boolean).join(' · ');

      item.append(name, details);
      item.addEventListener('click', () => {
        this.closeMenu(button, menu);
        this.fill(popup, kind, person);
      });
      menu.appendChild(item);
    }

    menu.hidden = false;
    button.setAttribute('aria-expanded', 'true');
    const first = menu.querySelector('button');
    if (first) first.focus();

    // Close when clicking anywhere else, or pressing Escape.
    const onOutside = (e) => {
      if (!menu.contains(e.target) && e.target !== button) this.closeMenu(button, menu);
    };
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      // Only close our list. Don't let this Escape close FamilySearch's whole popup.
      e.stopPropagation();
      e.preventDefault();
      this.closeMenu(button, menu);
      button.focus();
    };
    menu._cleanup = () => {
      document.removeEventListener('mousedown', onOutside, true);
      document.removeEventListener('keydown', onKey, true);
    };
    document.addEventListener('mousedown', onOutside, true);
    document.addEventListener('keydown', onKey, true);
  },

  closeMenu(button, menu) {
    menu.hidden = true;
    button.setAttribute('aria-expanded', 'false');
    if (menu._cleanup) menu._cleanup();
  },

  // ---------- Filling ----------

  async fill(popup, kind, person, { auto = false } = {}) {
    if (this.busy) {
      FSH.toast('Still filling, one moment…', 'info');
      return;
    }
    this.busy = true;
    try {
      if (kind.namesOnly) await this.fillName(popup, person, auto);
      else await this.fillFields(popup, person, auto);
    } finally {
      this.busy = false;
    }
  },

  // Alternate Name popup: just the name, as a starting point to edit.
  async fillName(popup, person, auto) {
    const s = this.selectors;
    const field = (selector) => popup.querySelector(selector);
    if (!field(s.firstName) || !field(s.lastName)) return;

    this.setText(field(s.firstName), person.given);
    this.setText(field(s.lastName), person.surname);
    this.setText(field(s.suffix), person.suffix);
    field(s.firstName).focus(); // ready for editing

    FSH.toast(`✓ ${auto ? 'Auto-filled' : 'Filled'} name: ${person.fullName}. Change it to the alternate name before saving.`, 'info');
  },

  // Add Unconnected Person form: everything.
  async fillFields(form, person, auto) {
    const s = this.selectors;
    const field = (selector) => form.querySelector(selector);

    if (!field(s.firstName) || !field(s.lastName)) {
      FSH.toast('⚠ Switch to the "By Name" tab, then try again.', 'warning');
      return;
    }

    FSH.toast(`${auto ? 'Auto-filling' : 'Filling'}: ${person.fullName}…`, 'info');

    // Names. Every field is set, even blank ones, so nothing is left over
    // from a person filled earlier.
    this.setText(field(s.firstName), person.given);
    this.setText(field(s.lastName), person.surname);
    this.setText(field(s.suffix), person.suffix);

    // Sex. If the record doesn't say (e.g. Find a Grave), you choose it. If a
    // sex is still selected from a person filled earlier, it's switched to
    // Unknown so it can't carry over by mistake.
    const notes = [];
    if (person.sex) {
      this.pickRadio(form, s.sex, person.sex.toLowerCase());
    } else {
      if (form.querySelector(`${s.sex}:checked`)) this.pickRadio(form, s.sex, 'unknown');
      notes.push('choose Male or Female (this record doesn\'t say)');
    }

    // Always deceased. We never add living people.
    this.pickRadio(form, s.status, 'deceased');

    // Dates and places, one at a time, because each opens a suggestion list.
    const notStandardized = [];
    if (!(await this.setDate(field(s.birthDate), person.birthDate))) notStandardized.push('birth date');
    await this.setPlace(field(s.birthPlace), person.birthPlace);
    if (!(await this.setDate(field(s.deathDate), person.deathDate))) notStandardized.push('death date');
    await this.setPlace(field(s.deathPlace), person.deathPlace);

    if (document.activeElement && form.contains(document.activeElement)) document.activeElement.blur();

    if (notStandardized.length) {
      notes.push(`check the ${notStandardized.join(' and ')} (no standardized suggestion was picked)`);
    }
    const done = auto
      ? `✓ Auto-filled: ${person.fullName} (not right? use Fill from saved)`
      : `✓ Filled: ${person.fullName}`;
    if (notes.length) {
      FSH.toast(`${done}. Please ${notes.join(', and ')}.`, 'warning');
    } else {
      FSH.toast(done);
    }
  },

  // Set an input's value in a way FamilySearch's page code notices.
  setValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  },

  setText(input, value) {
    if (!input) return;
    input.focus();
    this.setValue(input, value || '');
  },

  pickRadio(form, selector, value) {
    const radio = Array.from(form.querySelectorAll(selector)).find((r) => r.value === value);
    if (radio && !radio.checked) radio.click();
  },

  // Types the date, picks the standardized suggestion, and checks that
  // FamilySearch accepted it. Tries up to DATE_ATTEMPTS times, waiting a
  // little longer each time.
  // Returns true if standardized (or nothing to fill), false if it never was.
  async setDate(input, value) {
    if (!input) return !value;
    input.focus();
    if (!value) {
      this.setValue(input, '');
      return true;
    }

    for (let attempt = 1; attempt <= this.DATE_ATTEMPTS; attempt++) {
      // Re-focus every try: if the user clicked somewhere else meanwhile, the
      // suggestion list won't open for a field that isn't focused.
      input.focus();
      this.setValue(input, '');
      await this.wait(100 * attempt);
      await this.typeValue(input, value);

      const options = await this.waitForSuggestions(input, this.SUGGESTION_WAIT_MS + attempt * 1000);
      const standardized = options.find((option) => this.isStandardized(option));
      if (!standardized) continue;

      const wanted = this.normalize(standardized.textContent);
      standardized.click();

      // Give FamilySearch up to a second to accept it.
      for (let i = 0; i < 10; i++) {
        await this.wait(100);
        if (this.dateAccepted(input, wanted)) return true;
      }
    }
    return false;
  },

  // A standardized suggestion has an icon (the calendar); the "what you typed"
  // suggestion doesn't.
  isStandardized(option) {
    return option.querySelector('[is-icon], svg') !== null;
  },

  // FamilySearch shows a calendar icon in the field (has-icon) once a date is
  // standardized.
  dateAccepted(input, wanted) {
    return input.hasAttribute('has-icon') && this.normalize(input.value) === wanted;
  },

  normalize(text) {
    return (text || '').replace(/\s+/g, ' ').trim().toLowerCase();
  },

  async setPlace(input, value) {
    if (!input) return;
    input.focus();
    if (!value) {
      this.setValue(input, '');
      return;
    }
    await this.typeValue(input, value);
    if (!this.PICK_PLACE_SUGGESTION) return;
    const options = await this.waitForSuggestions(input);
    if (options.length) {
      options[0].click();
      await this.wait(200);
    }
  },

  // Put the whole value in at once, so FamilySearch makes exactly one search
  // for it. (Typing it in pieces makes several searches, and an older one can
  // finish last and replace the right suggestion list.)
  async typeValue(input, value) {
    this.setValue(input, value);
    await this.wait(50);
  },

  // Wait until this field's suggestion list is showing results for the full
  // text and has stopped changing. Returns its options, or [] if that didn't
  // happen in time.
  async waitForSuggestions(input, timeout = this.SUGGESTION_WAIT_MS) {
    const deadline = Date.now() + timeout;
    let last = '';
    let steadyChecks = 0;
    while (Date.now() < deadline) {
      await this.wait(100);
      const options = this.findSuggestions(input);

      // The first suggestion repeats what's in the field. If it doesn't match
      // the full text yet, the list is still for a half-typed value.
      const echo = options.find((o) => !this.isStandardized(o));
      const upToDate = !echo || this.normalize(echo.textContent) === this.normalize(input.value);

      const now = options.map((o) => o.textContent).join('|');
      if (options.length && upToDate && now === last) {
        if (++steadyChecks >= 4) return options; // unchanged for 400ms
      } else {
        steadyChecks = 0;
      }
      last = now;
    }
    return [];
  },

  // Finds the suggestion list that belongs to this field. FamilySearch shows
  // the list in a separate floating box, so we use the field's aria-controls
  // link, or else the open list closest to the field. Never another field's.
  findSuggestions(input) {
    const visible = (el) => el.getClientRects().length > 0;
    if (input.getAttribute('aria-expanded') !== 'true') return [];

    const listId = input.getAttribute('aria-controls') || input.getAttribute('aria-owns');
    let list = listId && document.getElementById(listId);

    if (!list || !visible(list)) {
      const field = input.getBoundingClientRect();
      let closest = null;
      let closestDistance = 150; // px; anything further away isn't this field's list
      for (const candidate of document.querySelectorAll('[role="listbox"]')) {
        if (!visible(candidate) || candidate.closest('[data-fsh-ui]')) continue;
        const box = candidate.getBoundingClientRect();
        const distance = Math.min(Math.abs(box.top - field.bottom), Math.abs(box.bottom - field.top)) +
          Math.abs(box.left - field.left);
        if (distance < closestDistance) {
          closest = candidate;
          closestDistance = distance;
        }
      }
      list = closest;
    }

    return list ? Array.from(list.querySelectorAll('[role="option"]')).filter(visible) : [];
  },

  wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
});