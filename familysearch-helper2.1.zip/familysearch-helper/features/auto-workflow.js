// features/auto-workflow.js
// Auto Workflow (off by default, switched on in the popup). Saves the
// repetitive clicks on a FamilySearch record page. It looks at the right-hand
// "Tree" area and, after a 3-second countdown you can cancel:
//
//   1. Match:  FamilySearch shows a "Possible Tree Match".
//              -> opens Source Linker (the "Attach to Tree" page).
//   2. None:   no match, and no Similar Record is attached to anyone.
//              -> reminds you to create a new person, opens Source Linker.
//   3. Verify: no match, but a Similar Record is "Attached To" someone.
//              -> opens that person's profile and Source Linker.
//
// Nothing is attached automatically: Source Linker still needs you to confirm.
//
// Also: when you come back to a Source Linker tab, it refreshes so a person
// you just created shows up. It won't refresh if a popup is open or you've
// typed in a text box there.

FSH.features.push({
  name: 'autoWorkflow',

  COUNTDOWN_SECONDS: 4,
  STEADY_MS: 1000,     // the page must stop changing for this long first
  GIVE_UP_MS: 20000,   // stop waiting for the page after this long

  // FamilySearch's own names for the elements we use. If FamilySearch changes
  // them, this is the only place that needs updating.
  selectors: {
    attachButton: 'a[data-testid="attachToFamilyTree-Button"]',
    person: '[data-testid="person"]',
    personName: '[data-testid="fullName"]',
    personLink: 'a[href*="/tree/person/"]'
  },
  text: {
    possibleMatch: 'Possible Tree Match',
    similarRecords: 'Similar Records',
    noSimilar: 'No similar records were found'
  },

  recordId: null,   // record page we're working on
  doneFor: null,    // record page we've already handled
  startedAt: 0,
  pending: '',
  pendingSince: 0,
  retryTimer: null,
  countdown: null,  // the countdown box, while it's showing

  start() {
    FSH.onDomChange(() => this.check());
    // Background tabs wait until you look at them.
    document.addEventListener('visibilitychange', () => this.check());
    this.check();

    this.setUpLinkerRefresh();
  },

  // ---------- Record page ----------

  check() {
    if (!FSH.settings.get('autoWorkflow')) return;
    if (!location.pathname.startsWith('/ark:/')) return;
    if (this.countdown) return;

    const id = location.pathname;
    if (id === this.doneFor) return;
    if (document.visibilityState !== 'visible') return;

    if (id !== this.recordId) {
      this.recordId = id;
      this.startedAt = Date.now();
      this.pending = '';
    }
    if (Date.now() - this.startedAt > this.GIVE_UP_MS) return;

    // Check again shortly, in case the page finishes loading without any
    // further changes.
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this.check(), 500);

    const plan = this.readPage();
    if (!plan) return;

    // Wait until the page has stopped changing.
    const signature = JSON.stringify(plan);
    if (signature !== this.pending) {
      this.pending = signature;
      this.pendingSince = Date.now();
      return;
    }
    if (Date.now() - this.pendingSince < this.STEADY_MS) return;

    clearTimeout(this.retryTimer);
    this.doneFor = id;
    this.run(plan, id);
  },

  // Works out which scenario this record is. Returns null while the page is
  // still loading (or if the record is already attached: no Attach button).
  readPage() {
    const attach = document.querySelector(this.selectors.attachButton);
    if (!attach) return null;
    const linker = new URL(attach.getAttribute('href'), location.origin).href;

    const heading = (text) => Array.from(document.querySelectorAll('h3'))
      .find((h) => h.textContent.trim() === text);

    // 1. FamilySearch's own match.
    const possible = heading(this.text.possibleMatch);
    if (possible) {
      return { scenario: 'match', linker, person: this.readPerson(possible.parentElement) };
    }

    // Similar Records load separately; wait until they're there.
    const similar = heading(this.text.similarRecords);
    if (!similar) return null;
    const list = similar.parentElement;
    const loaded = list.querySelector('li') || list.textContent.includes(this.text.noSimilar);
    if (!loaded) return null;

    // Everyone the Similar Records are attached to (each person once).
    const people = [];
    for (const card of list.querySelectorAll(this.selectors.person)) {
      const person = this.readPerson(card.parentElement);
      if (person && !people.some((p) => p.id === person.id)) people.push(person);
    }

    if (people.length === 0) return { scenario: 'none', linker };
    return { scenario: 'verify', linker, people };
  },

  // Name and tree ID from a person card inside the given area.
  readPerson(area) {
    const card = area && area.querySelector(this.selectors.person);
    const link = card && card.querySelector(this.selectors.personLink);
    if (!link) return null;
    const match = link.getAttribute('href').match(/\/tree\/person\/(?:details\/)?([A-Z0-9]{4}-[A-Z0-9]{3,4})/i);
    if (!match) return null;
    const name = card.querySelector(this.selectors.personName);
    return { id: match[1].toUpperCase(), name: name ? name.textContent.trim() : match[1] };
  },

  run(plan, recordPath) {
    const who = (p) => (p ? `${p.name} (${p.id})` : 'the suggested person');
    const profile = (p) => `${location.origin}/en/tree/person/details/${p.id}`;
    let type;
    let message;
    let tabs;

    if (plan.scenario === 'match') {
      type = 'match';
      message = `✓ FamilySearch found a match: ${who(plan.person)}. Opening Source Linker…`;
      tabs = [{ url: plan.linker, active: true }];
    } else if (plan.scenario === 'none') {
      type = 'none';
      message = 'No tree match. Create a new person (Add Unconnected Person), then attach this record. Opening Source Linker…';
      tabs = [{ url: plan.linker, active: true }];
    } else if (plan.people.length === 1) {
      type = 'verify';
      message = `Possible match from a similar record: ${who(plan.people[0])}. Check it's the same person. Opening their profile and Source Linker…`;
      tabs = [
        { url: profile(plan.people[0]), active: true },
        { url: plan.linker, active: false }
      ];
    } else {
      type = 'verify';
      message = `Similar records are attached to ${plan.people.length} different people (${plan.people.map(who).join(', ')}). Check the Similar Records list. Opening Source Linker…`;
      tabs = [{ url: plan.linker, active: true }];
    }

    this.showCountdown(type, message, async () => {
      if (location.pathname !== recordPath) return; // you've moved on
      try {
        const result = await chrome.runtime.sendMessage({ type: 'openTabs', tabs });
        if (!result || !result.ok) throw new Error('not opened');
      } catch (err) {
        FSH.toast('⚠ Couldn\'t open the new tab. Refresh this page and try again.', 'warning');
      }
    });
  },

  // A box at the top right with the message, a countdown and a Cancel button.
  showCountdown(type, message, action) {
    const box = document.createElement('div');
    box.className = 'fsh-countdown';
    box.dataset.type = type;
    box.setAttribute('data-fsh-ui', '');
    box.setAttribute('role', 'alert');

    const text = document.createElement('div');
    text.className = 'fsh-countdown-text';
    text.textContent = message;

    const footer = document.createElement('div');
    footer.className = 'fsh-countdown-footer';
    const timer = document.createElement('span');
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.textContent = 'Cancel';
    footer.append(timer, cancel);

    box.append(text, footer);
    document.body.appendChild(box);
    this.countdown = box;

    let remaining = this.COUNTDOWN_SECONDS;
    const tick = () => { timer.textContent = `Continuing in ${remaining}…`; };
    tick();

    const finish = () => {
      clearInterval(interval);
      document.removeEventListener('keydown', onKey, true);
      box.remove();
      this.countdown = null;
    };
    const interval = setInterval(() => {
      // Paused while you're on another tab; starts over when you come back.
      if (document.visibilityState !== 'visible') {
        remaining = this.COUNTDOWN_SECONDS;
        return tick();
      }
      remaining--;
      if (remaining > 0) return tick();
      finish();
      action();
    }, 1000);

    const onCancel = () => {
      finish();
      FSH.toast('Auto Workflow cancelled for this record.', 'info');
    };
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      e.stopPropagation();
      onCancel();
    };
    cancel.addEventListener('click', onCancel);
    document.addEventListener('keydown', onKey, true);
  },

  // ---------- Source Linker refresh ----------

  setUpLinkerRefresh() {
    let wasHidden = document.visibilityState === 'hidden';
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        wasHidden = true;
        return;
      }
      if (!wasHidden) return;
      wasHidden = false;

      if (!FSH.settings.get('autoWorkflow')) return;
      if (!location.pathname.includes('/search/linker')) return;

      if (this.hasUnsavedWork()) {
        FSH.toast('Not refreshing this page: you have a popup open or unsaved text.', 'info');
        return;
      }
      location.reload();
    });
  },

  // A popup open, or something typed in a text box (like the reason box).
  hasUnsavedWork() {
    if (document.querySelector('[role="dialog"]')) return true;
    return Array.from(document.querySelectorAll('textarea')).some((t) => t.value.trim() !== '');
  }
});