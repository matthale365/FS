// shared/watch.js
// One shared watcher for the whole page. FamilySearch builds its pages on the
// fly, so features use this to react when things appear or change:
//
//   FSH.watch(selector, fn)  - run fn(element) once for each element matching
//                              selector, now and whenever new ones appear.
//   FSH.onDomChange(fn)      - run fn() shortly after the page changes
//                              (bunched together so it doesn't run 100x a second).
//
// Anything our extension adds to the page should have the attribute
// data-fsh-ui, so changes we make ourselves don't trigger these watchers.

window.FSH = window.FSH || { features: [] };

(function () {
  const watchers = [];       // { selector, callback, seen }
  const changeListeners = []; // functions to call after the page changes
  let changeTimer = null;
  let observer = null;

  function check(root) {
    for (const w of watchers) {
      const found = [];
      if (root.matches && root.matches(w.selector)) found.push(root);
      if (root.querySelectorAll) found.push(...root.querySelectorAll(w.selector));
      for (const el of found) {
        if (w.seen.has(el)) continue; // only handle each element once
        w.seen.add(el);
        try {
          w.callback(el);
        } catch (err) {
          console.error('[FS Helper] watcher error for', w.selector, err);
        }
      }
    }
  }

  function isOurs(node) {
    const el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    return !!(el && el.closest('[data-fsh-ui]'));
  }

  function scheduleChange() {
    clearTimeout(changeTimer);
    changeTimer = setTimeout(() => {
      for (const fn of changeListeners) {
        try {
          fn();
        } catch (err) {
          console.error('[FS Helper] change listener error', err);
        }
      }
    }, 100);
  }

  function start() {
    if (observer) return;
    observer = new MutationObserver((mutations) => {
      let pageChanged = false;
      for (const m of mutations) {
        if (!isOurs(m.target)) pageChanged = true;
        for (const node of m.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) check(node);
        }
      }
      if (pageChanged && changeListeners.length) scheduleChange();
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  FSH.watch = function (selector, callback) {
    watchers.push({ selector, callback, seen: new WeakSet() });
    start();
    check(document.body);
  };

  FSH.onDomChange = function (callback) {
    changeListeners.push(callback);
    start();
  };
})();
