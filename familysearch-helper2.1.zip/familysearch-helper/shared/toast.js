// shared/toast.js
// Small notification in the bottom-right corner. Only one shows at a time:
// a new one replaces the old one instead of stacking up.
//
//   FSH.toast('Saved: Jane Doe')            - green, for success
//   FSH.toast('Something to know', 'info')  - blue
//   FSH.toast('Something went wrong', 'warning') - orange, stays longer

window.FSH = window.FSH || { features: [] };

FSH.toast = (function () {
  let box = null;
  let hideTimer = null;

  return function toast(message, type = 'success') {
    if (!box) {
      box = document.createElement('div');
      box.className = 'fsh-toast';
      box.setAttribute('data-fsh-ui', '');
      box.setAttribute('role', 'status');
      box.addEventListener('click', () => box.classList.remove('fsh-toast-show'));
    }
    if (!box.isConnected) document.body.appendChild(box);

    box.textContent = message;
    box.dataset.type = type;

    // Restart the fade-in so a replaced message is noticeable.
    box.classList.remove('fsh-toast-show');
    void box.offsetWidth;
    box.classList.add('fsh-toast-show');

    clearTimeout(hideTimer);
    hideTimer = setTimeout(
      () => box.classList.remove('fsh-toast-show'),
      type === 'warning' ? 8000 : 4000
    );
  };
})();