// shared/settings.js
// Every on/off setting lives here, with its default value. Both the popup and
// the features on the page use this file, so they always agree.
//
// To add a new setting later: add it to DEFAULTS below, then add a switch for
// it in popup/popup.html.

window.FSH = window.FSH || { features: [] };

FSH.settings = (function () {
    const DEFAULTS = {
    autoFilter: true,
    autoFill: false,
    autoWorkflow: false
  };

  let values = { ...DEFAULTS };
  const listeners = [];

  // Saved settings follow the signed-in Chrome profile (chrome.storage.sync).
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    for (const [key, change] of Object.entries(changes)) {
      if (!(key in DEFAULTS)) continue;
      values[key] = change.newValue ?? DEFAULTS[key];
      for (const fn of listeners) fn(key, values[key]);
    }
  });

  return {
    DEFAULTS,

    // Read saved settings. Call once before using get().
    load() {
      return new Promise((resolve) => {
        chrome.storage.sync.get(DEFAULTS, (saved) => {
          values = { ...DEFAULTS, ...saved };
          resolve(values);
        });
      });
    },

    get(key) {
      return values[key];
    },

    set(key, value) {
      return new Promise((resolve) => chrome.storage.sync.set({ [key]: value }, resolve));
    },

    // fn(key, newValue) runs whenever a setting changes, e.g. from the popup.
    onChange(fn) {
      listeners.push(fn);
    }
  };
})();
