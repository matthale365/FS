// popup/popup.js

// ---------- Settings switches ----------
// Any <input data-setting="name"> is connected automatically, so adding a new
// switch only needs a new line of HTML (plus the default in shared/settings.js).
FSH.settings.load().then(() => {
  document.querySelectorAll('[data-setting]').forEach((input) => {
    const key = input.dataset.setting;
    input.checked = !!FSH.settings.get(key);
    input.addEventListener('change', () => FSH.settings.set(key, input.checked));
  });
});

// ---------- Saved people ----------
const savedList = document.getElementById('savedList');
const savedEmpty = document.getElementById('savedEmpty');
const clearButton = document.getElementById('clearSaved');
const extractButton = document.getElementById('extractNow');
const statusText = document.getElementById('status');

function years(person) {
  const year = (d) => ((d || '').match(/\d{4}/g) || []).pop() || '';
  const b = year(person.birthDate);
  const d = year(person.deathDate);
  if (b && d) return `${b}–${d}`;
  if (b) return `b. ${b}`;
  if (d) return `d. ${d}`;
  return '';
}

function showSaved(people) {
  savedList.textContent = '';
  for (const person of people) {
    const item = document.createElement('li');

    const name = document.createElement('span');
    name.className = 'saved-name';
    // First and last name only (the full name is shown when you hover).
    name.textContent = [person.given.split(' ')[0], person.surname].filter(Boolean).join(' ');
    name.title = person.fullName;

    const dates = document.createElement('span');
    dates.className = 'saved-years';
    dates.textContent = years(person);

    item.append(name, dates);
    savedList.appendChild(item);
  }
  savedEmpty.hidden = people.length > 0;
  clearButton.hidden = people.length === 0;
}

function loadSaved() {
  chrome.storage.session.get('savedPeople', ({ savedPeople = [] }) => showSaved(savedPeople));
}

// Update the list live if something is saved while the popup is open.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && changes.savedPeople) showSaved(changes.savedPeople.newValue || []);
});

clearButton.addEventListener('click', () => {
  chrome.storage.session.remove('savedPeople');
  setStatus('History cleared.');
});

extractButton.addEventListener('click', async () => {
  setStatus('Extracting…');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return setStatus('No open tab found.', true);

  try {
    const result = await chrome.tabs.sendMessage(tab.id, { type: 'extractNow' });
    if (!result) return setStatus('This page doesn\'t support extraction.', true);
    setStatus(result.message, !result.ok);
  } catch (err) {
    // No extension code on this tab: wrong site, or the tab was open before
    // the extension was installed/reloaded.
    setStatus('Can\'t extract here. Open a record page, or refresh it and try again.', true);
  }
});

function setStatus(message, isError = false) {
  statusText.textContent = message;
  statusText.dataset.error = isError ? 'true' : 'false';
}

loadSaved();

document.getElementById('version').textContent =
  'Version ' + chrome.runtime.getManifest().version;