// main.js
// Runs last. Loads saved settings, then starts every feature that the files
// above added to FSH.features.

FSH.settings.load().then(() => {
  for (const feature of FSH.features) {
    try {
      feature.start();
      console.log(`[FS Helper] started: ${feature.name}`);
    } catch (err) {
      console.error(`[FS Helper] failed to start: ${feature.name}`, err);
    }
  }
});
