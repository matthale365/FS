// features/fill-form.js
// Adds a "Fill from saved" button next to the title of FamilySearch's
// "Add Unconnected Person" form. Clicking it lists your saved people; picking
// one fills the form with that person. Nothing is filled automatically.

FSH.features.push({
  name: 'fillForm',

  // FamilySearch's own names for the elements we use. If FamilySearch changes
  // them, this is the only place that needs updating.
  selectors: {
    form: '[data-testid="add-find-flow"]',
    titleGroup: '[data-overlay-header]',
    firstName: 'input[data-testid="first-name"]',
    lastName: 'input[data-testid="last-name"]',
    suffix: 'input[data-testid="suffix"]',
    sex: 'input[type="radio"][name="sex"]',
    status: 'input[type="radio"][name="status"]',
    birthDate: 'input[name="birthDate"]',
    birthPlace: 'input[name="birthPlace"]',
    deathDate: 'input[name="deathDate"]',
    deathPlace: 'input[name="deathPlace"]'
  },

  // Dates: after typing, pick FamilySearch's standardized date from the
  // suggestion list (same choice the old version made).
  // Places: typed in as-is. Set this to true to also pick the first place
  // suggestion automatically.
  PICK_PLACE_SUGGESTION: false,
  SUGGESTION_WAIT_MS: 3000,

  start() {
    FSH.watch(this.selectors.form, (form) => this.addButton(form));
    // In case FamilySearch redraws the header and removes our button.
    FSH.onDomChange(() => {
      document.querySelectorAll(this.selectors.form).forEach((form) => this.addButton(form));
    });
  },

  // ---------- The button and person picker ----------

  addButton(form) {
    if (form.querySelector('.fsh-fill')) return;
    const titleGroup = form.querySelector(this.selectors.titleGroup);
    if (!titleGroup || !titleGroup.parentElement) return;

    const wrapper = document.createElement('div');
    wrapper.className = 'fsh-fill';
    wrapper.setAttribute('data-fsh-ui', '');

    // The header is also the handle for dragging the window. Stop our clicks
    // from reaching it so pressing the button doesn't start a drag.
    for (const type of ['pointerdown', 'mousedown', 'touchstart', 'keydown']) {
      wrapper.addEventListener(type, (e) => e.stopPropagation());
    }

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'fsh-fill-button';
    button.textContent = 'Fill from saved ▾';
    button.setAttribute('aria-haspopup', 'true');
    button.setAttribute('aria-expanded', 'false');

    const menu = document.createElement('div');
    menu.className = 'fsh-fill-menu';
    menu.hidden = true;

    button.addEventListener('click', () => {
      if (menu.hidden) this.openMenu(form, button, menu);
      else this.closeMenu(button, menu);
    });

    wrapper.append(button, menu);
    // Right after the title, in the same row.
    titleGroup.parentElement.after(wrapper);
  },

  async openMenu(form, button, menu) {
    let people = [];
    try {
      people = await chrome.runtime.sendMessage({ type: 'getSavedPeople' });
    } catch (err) {
      FSH.toast('⚠ Couldn\'t load saved people. Refresh this page and try again.', 'warning');
      return;
    }

    menu.textContent = '';
    if (!people || people.length === 0) {
      const empty = document.createElement('p');
      empty.className = 'fsh-fill-empty';
      empty.textContent = 'No saved people yet. Open a record first and it will be saved.';
      menu.appendChild(empty);
    }

    for (const person of people || []) {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'fsh-fill-item';

      const name = document.createElement('span');
      name.className = 'fsh-fill-name';
      name.textContent = person.fullName;

      const details = document.createElement('span');
      details.className = 'fsh-fill-details';
      details.textContent = [
        FSH.extract.years(person),
        person.marriedSurname ? `married ${person.marriedSurname}` : '',
        person.birthPlace
      ].filter(Boolean).join(' · ');

      item.append(name, details);
      item.addEventListener('click', () => {
        this.closeMenu(button, menu);
        this.fill(form, person);
      });
      menu.appendChild(item);
    }

    menu.hidden = false;
    button.setAttribute('aria-expanded', 'true');
    const first = menu.querySelector('button');
    if (first) first.focus();

    // Close when clicking anywhere else, or pressing Escape.
    const onOutside = (e) => {
      if (!menu.contains(e.target) && e.target !== button) this.closeMenu(button, menu);
    };
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      // Only close our list. Don't let this Escape close FamilySearch's whole form.
      e.stopPropagation();
      e.preventDefault();
      this.closeMenu(button, menu);
      button.focus();
    };
    menu._cleanup = () => {
      document.removeEventListener('mousedown', onOutside, true);
      document.removeEventListener('keydown', onKey, true);
    };
    document.addEventListener('mousedown', onOutside, true);
    document.addEventListener('keydown', onKey, true);
  },

  closeMenu(button, menu) {
    menu.hidden = true;
    button.setAttribute('aria-expanded', 'false');
    if (menu._cleanup) menu._cleanup();
  },

  // ---------- Filling the form ----------

  async fill(form, person) {
    const s = this.selectors;
    const field = (selector) => form.querySelector(selector);

    if (!field(s.firstName) || !field(s.lastName)) {
      FSH.toast('⚠ Switch to the "By Name" tab, then try again.', 'warning');
      return;
    }

    FSH.toast(`Filling: ${person.fullName}…`, 'info');

    // Names. Every field is set, even blank ones, so nothing is left over
    // from a person filled earlier.
    this.setText(field(s.firstName), person.given);
    this.setText(field(s.lastName), person.surname);
    this.setText(field(s.suffix), person.suffix);

    // Sex. If the record doesn't say (e.g. Find a Grave), you choose it. If a
    // sex is still selected from a person filled earlier, it's switched to
    // Unknown so it can't carry over by mistake.
    const notes = [];
    if (person.sex) {
      this.pickRadio(form, s.sex, person.sex.toLowerCase());
    } else {
      if (form.querySelector(`${s.sex}:checked`)) this.pickRadio(form, s.sex, 'unknown');
      notes.push('choose Male or Female (this record doesn\'t say)');
    }

    // Always deceased. We never add living people.
    this.pickRadio(form, s.status, 'deceased');

    // Dates and places, one at a time, because each opens a suggestion list.
    const notStandardized = [];
    if (!(await this.setDate(field(s.birthDate), person.birthDate))) notStandardized.push('birth date');
    await this.setPlace(field(s.birthPlace), person.birthPlace);
    if (!(await this.setDate(field(s.deathDate), person.deathDate))) notStandardized.push('death date');
    await this.setPlace(field(s.deathPlace), person.deathPlace);

    if (document.activeElement && form.contains(document.activeElement)) document.activeElement.blur();

    if (notStandardized.length) {
      notes.push(`check the ${notStandardized.join(' and ')} (no standardized suggestion was picked)`);
    }
    if (notes.length) {
      FSH.toast(`✓ Filled: ${person.fullName}. Please ${notes.join(', and ')}.`, 'warning');
    } else {
      FSH.toast(`✓ Filled: ${person.fullName}`);
    }
  },

  // Set an input's value in a way FamilySearch's page code notices.
  setValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  },

  setText(input, value) {
    if (!input) return;
    input.focus();
    this.setValue(input, value || '');
  },

  pickRadio(form, selector, value) {
    const radio = Array.from(form.querySelectorAll(selector)).find((r) => r.value === value);
    if (radio && !radio.checked) radio.click();
  },

  // Types the value, then picks from the suggestion list.
  // Returns true if done (or nothing to fill), false if no suggestion was picked.
  async setDate(input, value) {
    if (!input) return !value;
    input.focus();
    if (!value) {
      this.setValue(input, '');
      return true;
    }
    await this.typeValue(input, value);
    const options = await this.waitForSuggestions(input);
    if (!options.length) return false;
    // Same choice as the old version: the 2nd suggestion when there are
    // several (the standardized date), otherwise the only one.
    (options.length > 1 ? options[1] : options[0]).click();
    await this.wait(200);
    return true;
  },

  async setPlace(input, value) {
    if (!input) return;
    input.focus();
    if (!value) {
      this.setValue(input, '');
      return;
    }
    await this.typeValue(input, value);
    if (!this.PICK_PLACE_SUGGESTION) return;
    const options = await this.waitForSuggestions(input);
    if (options.length) {
      options[0].click();
      await this.wait(200);
    }
  },

  // Type it like a person would (all but the last letter, then the rest),
  // so FamilySearch loads suggestions for the full text.
  async typeValue(input, value) {
    this.setValue(input, value.slice(0, -1));
    await this.wait(60);
    this.setValue(input, value);
  },

  // Wait until this field's suggestion list appears and stops changing.
  // Returns the list of options, or [] if none showed up in time.
  async waitForSuggestions(input) {
    const deadline = Date.now() + this.SUGGESTION_WAIT_MS;
    let last = '';
    let steadyChecks = 0;
    while (Date.now() < deadline) {
      await this.wait(100);
      const options = this.findSuggestions(input);
      const now = options.map((o) => o.textContent).join('|');
      if (options.length && now === last) {
        if (++steadyChecks >= 3) return options; // unchanged for 300ms
      } else {
        steadyChecks = 0;
      }
      last = now;
    }
    return [];
  },

  findSuggestions(input) {
    const visible = (el) => el.getClientRects().length > 0;
    const listId = input.getAttribute('aria-controls') || input.getAttribute('aria-owns');
    const list = (listId && document.getElementById(listId)) || input.closest('.autosuggest-wrapper');
    let options = list ? Array.from(list.querySelectorAll('[role="option"]')) : [];
    if (!options.length && input.getAttribute('aria-expanded') === 'true') {
      options = Array.from(document.querySelectorAll('[role="listbox"] [role="option"]'));
    }
    return options.filter(visible);
  },

  wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
});