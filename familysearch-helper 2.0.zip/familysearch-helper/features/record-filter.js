// features/record-filter.js
// On FamilySearch search results, hide records that are already attached to
// the tree, so only possible matches and no-match records are left to work on.
//
// How it stays reliable:
// - It only hides a row when it actually sees the "attached" button in it.
//   A row that's still loading stays visible until that button shows up, so
//   nothing gets hidden too early.
// - It re-checks every row whenever the page changes (late-loading icons, next
//   page, new search), so there's no fixed timer to get wrong.
// - A bar above the results shows what it did, with "Filter now" and
//   "Show all" buttons that work even when Auto Filter is off.

FSH.features.push({
  name: 'recordFilter',

  // FamilySearch's own names for the elements we use. If FamilySearch changes
  // them, this is the only place that needs updating.
  selectors: {
    row: 'tr[data-testid^="/ark:"]',
    attached: '[aria-label^="View attached tree person"]'
  },

  active: false, // is the filter currently hiding rows on this page?
  lastUrl: null,
  bar: null,

  start() {
    this.active = FSH.settings.get('autoFilter');
    this.lastUrl = location.href;

    // Turning Auto Filter on/off in the popup applies immediately.
    FSH.settings.onChange((key, value) => {
      if (key !== 'autoFilter') return;
      this.active = value;
      this.refresh();
    });

    FSH.onDomChange(() => this.refresh());
    this.refresh();
  },

  refresh() {
    // New search or next page: go back to whatever the Auto Filter setting says.
    if (location.href !== this.lastUrl) {
      this.lastUrl = location.href;
      this.active = FSH.settings.get('autoFilter');
    }

    const rows = Array.from(document.querySelectorAll(this.selectors.row));
    if (rows.length === 0) {
      if (this.bar) this.bar.remove();
      return;
    }

    let hidden = 0;
    for (const row of rows) {
      const hide = this.active && row.querySelector(this.selectors.attached) !== null;
      if (hide) {
        hidden++;
        if (!row.hasAttribute('data-fsh-hidden')) row.setAttribute('data-fsh-hidden', '');
      } else if (row.hasAttribute('data-fsh-hidden')) {
        row.removeAttribute('data-fsh-hidden');
      }
    }

    this.updateBar(rows, hidden);
  },

  updateBar(rows, hidden) {
    if (!this.bar) this.bar = this.buildBar();

    // Keep the bar directly above the results table.
    const table = rows[0].closest('table');
    const anchor = table || rows[0].parentElement;
    if (this.bar.nextElementSibling !== anchor) anchor.before(this.bar);

    const total = rows.length;
    let text;
    if (!this.active) {
      text = `Filter off · ${total} records`;
    } else if (hidden === total) {
      text = `Filter on · All ${total} records here are already attached`;
    } else {
      text = `Filter on · Showing ${total - hidden} of ${total} (${hidden} attached hidden)`;
    }

    // Only touch the page when something actually changed.
    if (this.barText.textContent !== text) this.barText.textContent = text;
    this.barText.dataset.state = this.active ? 'on' : 'off';
    this.showAllButton.hidden = !this.active;
    this.filterButton.textContent = this.active ? 'Re-run filter' : 'Filter now';
  },

  buildBar() {
    const bar = document.createElement('div');
    bar.className = 'fsh-filter-bar';
    bar.setAttribute('data-fsh-ui', '');
    bar.setAttribute('role', 'status');

    this.barText = document.createElement('span');
    this.barText.className = 'fsh-filter-text';

    this.filterButton = document.createElement('button');
    this.filterButton.type = 'button';
    this.filterButton.addEventListener('click', () => {
      this.active = true;
      this.refresh();
    });

    this.showAllButton = document.createElement('button');
    this.showAllButton.type = 'button';
    this.showAllButton.textContent = 'Show all';
    this.showAllButton.addEventListener('click', () => {
      this.active = false;
      this.refresh();
    });

    bar.append(this.barText, this.filterButton, this.showAllButton);
    return bar;
  }
});
