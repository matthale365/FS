// Runs in PAGE context — can access React fiber and patch event listeners

// ── Patch dismiss handlers ────────────────────────────────────────────────
// Wrap document/window mousedown+click listeners so they ignore clicks
// whose target is our nav button.
const BTN_ID = 'fs-quick-add-nav-btn';
const _origAEL = EventTarget.prototype.addEventListener;
EventTarget.prototype.addEventListener = function (type, listener, options) {
  if (typeof listener !== 'function') {
    return _origAEL.call(this, type, listener, options);
  }
  if ((type === 'mousedown' || type === 'click') &&
      (this === document || this === window)) {
    const wrapped = function (e) {
      if (e.target && e.target.closest && e.target.closest('#' + BTN_ID)) return;
      return listener.call(this, e);
    };
    return _origAEL.call(this, type, wrapped, options);
  }
  return _origAEL.call(this, type, listener, options);
};

// ── React fiber click bridge ──────────────────────────────────────────────
window.addEventListener('fs-quick-add', function (e) {
  const btn = document.querySelector(e.detail.selector);
  if (!btn) return;
  const key = Object.keys(btn).find(k => k.startsWith('__reactFiber'));
  const onClick = btn[key]?.memoizedProps?.onClick;
  if (onClick) {
    onClick({
      type: 'click', bubbles: true,
      currentTarget: btn, target: btn,
      preventDefault: () => {}, stopPropagation: () => {}
    });
  }
});