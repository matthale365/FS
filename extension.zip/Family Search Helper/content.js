// ========================================
// TIMING CONFIGURATION
// ========================================
const TIMING = {
  FIELD_DELAY: 50,
  DATE_FOCUS_DELAY: 100,
  DATE_TRIGGER_DELAY: 100,
  AUTOCOMPLETE_CHECK: 200,
  AUTOCOMPLETE_CLICK_DELAY: 200,
  AUTOCOMPLETE_TIMEOUT: 30,
  WORKFLOW_COUNTDOWN: 3  // Seconds before auto-action executes (NUMIDENT workflow)
};

// ========================================
// NOTIFICATION SYSTEM
// ========================================
function showNotification(message, type = 'success') {
  const notification = document.createElement('div');
  notification.textContent = message;
  
  const colors = { success: '#10b981', info: '#3b82f6', warning: '#f59e0b' };
  
  notification.style.cssText = `
    position: fixed; bottom: 20px; right: 20px;
    background: ${colors[type] || colors.success};
    color: white; padding: 12px 20px; border-radius: 6px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    font-size: 13px; font-weight: 500; z-index: 10000;
    opacity: 0; transition: opacity 0.3s ease;
  `;
  
  document.body.appendChild(notification);
  setTimeout(() => notification.style.opacity = '1', 10);
  setTimeout(() => {
    notification.style.opacity = '0';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

function showCountdownNotification(message, seconds, callback) {
  const notification = document.createElement('div');
  const messageSpan = document.createElement('div');
  const cancelButton = document.createElement('button');
  let remaining = seconds;
  let cancelled = false;
  let interval;
  
  notification.style.cssText = `
    position: fixed; top: 20px; right: 20px;
    background: #3b82f6; color: white;
    padding: 16px 24px; border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    font-size: 14px; font-weight: 600; z-index: 10000;
    min-width: 300px; text-align: center;
    display: flex; flex-direction: column; gap: 12px;
  `;
  
  messageSpan.style.cssText = `
    font-size: 14px;
  `;
  
  cancelButton.textContent = 'Cancel';
  cancelButton.style.cssText = `
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
    padding: 6px 16px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    transition: background 0.2s;
  `;
  
  cancelButton.onmouseover = () => {
    cancelButton.style.background = 'rgba(255, 255, 255, 0.3)';
  };
  
  cancelButton.onmouseout = () => {
    cancelButton.style.background = 'rgba(255, 255, 255, 0.2)';
  };
  
  cancelButton.onclick = () => {
    cancelled = true;
    clearInterval(interval);
    notification.remove();
    showNotification("✗ Action cancelled", 'info');
  };
  
  const updateText = () => {
    messageSpan.textContent = `${message} (${remaining}s)`;
  };
  
  updateText();
  notification.appendChild(messageSpan);
  notification.appendChild(cancelButton);
  document.body.appendChild(notification);
  
  interval = setInterval(() => {
    remaining--;
    if (remaining > 0) {
      updateText();
    } else {
      clearInterval(interval);
      notification.remove();
      if (callback && !cancelled) callback();
    }
  }, 1000);
}

// ========================================
// SETTINGS & INITIALIZATION
// ========================================
let settings = { autoFilter: true, autoExtract: true, autoFill: true, autoWorkflow: true };

chrome.storage.sync.get(['settings'], (result) => {
  if (result.settings) settings = { ...settings, ...result.settings };
  console.log("📋 Settings loaded:", settings);
  init();
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.settings) {
    const oldSettings = settings;
    settings = { ...settings, ...changes.settings.newValue };
    
    const url = location.href;
    
    // If autoFilter was just turned ON
    if (!oldSettings.autoFilter && settings.autoFilter) {
      if (url.includes("familysearch.org/en/search/record/")) {
        console.log("🔄 Auto Filter enabled - running filter...");
        runFilterAction();
      }
    }
    
    // If autoExtract was just turned ON
    if (!oldSettings.autoExtract && settings.autoExtract) {
      if (url.includes("familysearch.org/ark:/")) {
        console.log("🔄 Auto Extract enabled - extracting data...");
        extractFamilySearchData();
      } else if (url.includes("ancestry.com/family-tree/person/tree") || 
                 url.includes("ancestryinstitution.com/family-tree/person/tree")) {
        console.log("🔄 Auto Extract enabled - extracting data...");
        extractAncestryData();
      } else if (url.includes("findagrave.com/memorial/")) {
        console.log("🔄 Auto Extract enabled - extracting data...");
        extractFindAGraveData();
      }
    }
    
    // If autoWorkflow was just turned ON
    if (!oldSettings.autoWorkflow && settings.autoWorkflow) {
      if (url.includes("familysearch.org/ark:/")) {
        console.log("🔄 Auto Workflow enabled - detecting workflow...");
        detectAndHandleNumidentWorkflow();
      }
    }
  }
});

function init() {
  const url = location.href;
  
  // Auto Filter on FamilySearch record pages
  if (url.includes("familysearch.org/en/search/record/") && settings.autoFilter) {
    setupFilterObserver();
  }
  
  // NUMIDENT workflow detection - this will handle extraction when needed
  if (url.includes("familysearch.org/ark:/") && settings.autoWorkflow) {
    detectAndHandleNumidentWorkflow();
  }
  
  if (settings.autoExtract) {
    if (url.includes("ancestry.com/family-tree/person/tree") || 
        url.includes("ancestryinstitution.com/family-tree/person/tree")) waitForAncestryData();
    else if (url.includes("findagrave.com/memorial/")) waitForFindAGraveData();
  }
  
  if (url.includes("familysearch.org") && settings.autoFill) {
    setupFormFillObserver();
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'runFilter') runFilterAction();  // Manual button always works
  else if (request.action === 'runExtract') runExtractForCurrentPage();
  else if (request.action === 'runAutoFill') fillPersonForm();
  sendResponse({ success: true });
  return true;
});

// ========================================
// NUMIDENT AUTO-WORKFLOW
// ========================================
function detectAndHandleNumidentWorkflow() {
  if (!settings.autoWorkflow) return;  // Check setting
  
  console.log("🔍 Checking NUMIDENT workflow...");
  
  // Wait for page to fully load
  setTimeout(() => {
    // Option 3: Check for "Attach to Tree" button (definite match with blue highlight)
    // This appears with "Possible Tree Match" section and blue button
    let attachButton = document.querySelector('a[data-testid="attachToFamilyTree-Button"]');
    
    // Fallback: also check for any link/button with "Attach to Tree" text
    if (!attachButton) {
      attachButton = Array.from(document.querySelectorAll('a, button')).find(btn => 
        btn.textContent.trim() === "Attach to Tree" && btn.offsetParent !== null
      );
    }
    
    // Also check for "Possible Tree Match" header to confirm this is Option 3
    const possibleTreeMatchHeader = Array.from(document.querySelectorAll('*')).find(el => 
      el.textContent.trim() === "Possible Tree Match" && el.offsetParent !== null
    );
    
    if (attachButton && possibleTreeMatchHeader) {
      console.log("✅ Option 3: Definite match - will click ATTACH TO TREE button");
      console.log("Button found:", attachButton);
      showCountdownNotification(
        "✓ Definite match found! Clicking ATTACH TO TREE...",
        TIMING.WORKFLOW_COUNTDOWN,
        () => {
          // Simulate a real click
          attachButton.click();
          showNotification("✓ Clicked attach button - redirecting...", 'success');
        }
      );
      return;
    }
    
    // Option 2: Check for "Attached To:" section (already attached, possible match)
    // This should click ATTACH TO TREE button AND open the person's profile page
    const attachedToHeader = Array.from(document.querySelectorAll('*')).find(el => 
      el.textContent.trim() === "Attached To:" && el.offsetParent !== null
    );
    
    if (attachedToHeader) {
      console.log("✅ Option 2: Found 'Attached To:' - looking for person link and attach button");
      
      // Look for the person link near the "Attached To:" text
      const parentSection = attachedToHeader.closest('div');
      
      // Look for person links - they typically have the person's name and ID
      const personLinks = Array.from(document.querySelectorAll('a[href*="/tree/person/"]'));
      
      // Find the link in the "Attached To" section (usually in the right sidebar)
      let personLink = null;
      if (parentSection) {
        personLink = parentSection.querySelector('a[href*="/tree/person/"]');
      }
      
      // Fallback: find any person link in the right side of the page
      if (!personLink && personLinks.length > 0) {
        personLink = personLinks[0];
      }
      
      // Also find the ATTACH TO TREE button
      let attachButton = document.querySelector('a[data-testid="attachToFamilyTree-Button"]');
      if (!attachButton) {
        attachButton = Array.from(document.querySelectorAll('a, button')).find(btn => 
          btn.textContent.trim() === "Attach to Tree" && btn.offsetParent !== null
        );
      }
      
      if (personLink) {
        const personId = personLink.href.match(/\/tree\/person\/([^/?]+)/)?.[1];
        const personName = personLink.textContent.trim();
        
        if (personId) {
          showCountdownNotification(
            `⚠️ Attached to: ${personName}. Opening pages...`,
            TIMING.WORKFLOW_COUNTDOWN,
            () => {
              // Copy ID to clipboard
              navigator.clipboard.writeText(personId).then(() => {
                showNotification(`✓ Copied ID: ${personId}`, 'info');
              }).catch(() => {
                console.log("Clipboard copy failed, continuing anyway");
              });
              
              // First, click the ATTACH TO TREE button (if found)
              if (attachButton) {
                console.log("Clicking ATTACH TO TREE button...");
                attachButton.click();
                showNotification("✓ Clicked attach button", 'success');
                
                // Wait a moment, then open person page
                setTimeout(() => {
                  const newUrl = `https://www.familysearch.org/tree/person/${personId}`;
                  window.open(newUrl, '_blank');
                  showNotification(`✓ Opened: ${personName}`, 'success');
                }, 1000); // 1 second delay between actions
              } else {
                // If no attach button found, just open person page
                const newUrl = `https://www.familysearch.org/tree/person/${personId}`;
                window.open(newUrl, '_blank');
                showNotification(`✓ Opened: ${personName}`, 'success');
              }
            }
          );
          return;
        }
      }
    }
    
    // Option 1: No matches found - create new person
    // This is when there's only "Similar Records" section, no "Attached To:" or "Possible Tree Match"
    console.log("✅ Option 1: No matches found");
    // Extract data immediately (no waiting for countdown)
    waitForFamilySearchData();
    // Show countdown notification (user can cancel if needed)
    showCountdownNotification("ℹ️ No matches found. Create new person.", TIMING.WORKFLOW_COUNTDOWN);
    
  }, 2000); // Initial delay to let page load
}

// ========================================
// FILTER
// ========================================
function setupFilterObserver() {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(runFilter, 3000));
  } else {
    setTimeout(runFilter, 3000);
  }
  
  let lastRowCount = 0, lastDataCount = 0, stableChecks = 0, checkTimeout;
  let lastUrl = location.href;
  
  const observer = new MutationObserver((mutations) => {
    let rowsAdded = false;
    
    // Check for URL change (page navigation)
    const currentUrl = location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      setTimeout(runFilter, 2000);
    }
    
    // Check for added rows
    for (let mutation of mutations) {
      for (let node of mutation.addedNodes) {
        if (node.nodeType === 1 && (node.tagName === 'TR' || node.tagName === 'TBODY')) {
          rowsAdded = true;
          break;
        }
      }
      if (rowsAdded) break;
    }
    
    if (rowsAdded) {
      clearTimeout(checkTimeout);
      stableChecks = 0;
      
      const checkIfStable = () => {
        const currentRowCount = document.querySelectorAll('tbody tr').length;
        const dataElements = document.querySelectorAll('tbody tr .leftSideCss_lebwza5, tbody tr strong, tbody tr a[href*="/ark"]').length;
        
        if (currentRowCount === lastRowCount && dataElements === lastDataCount && currentRowCount > 0 && dataElements > 0) {
          stableChecks++;
          if (stableChecks >= 3) {
            runFilter();
            return;
          }
        } else {
          stableChecks = 0;
        }
        
        lastRowCount = currentRowCount;
        lastDataCount = dataElements;
        
        if (stableChecks < 40) {
          checkTimeout = setTimeout(checkIfStable, 500);
        } else {
          runFilter();
        }
      };
      
      checkTimeout = setTimeout(checkIfStable, 1500);
    }
  });
  
  observer.observe(document.body, { childList: true, subtree: true });
  window.addEventListener('focus', () => setTimeout(runFilter, 500));
}

function runFilter() {
  if (!settings.autoFilter) return;  // Check for AUTO filter
  runFilterAction();  // Call the actual filter function
}

function runFilterAction() {
  const tbodies = document.getElementsByTagName("tbody");
  if (tbodies.length === 0) return;
  
  let hiddenCount = 0, totalCount = 0;
  
  for (let tbody of tbodies) {
    const allChunks = tbody.getElementsByTagName("tr");
    totalCount += allChunks.length;
    
    for (let chunk of allChunks) {
      let hasMatch = false;
      const chunkElements = chunk.getElementsByTagName("*");
      
      for (let element of chunkElements) {
        if (element.innerHTML.includes("color: var(--gray00a)") ||
            (element.textContent && element.textContent.includes("View possible tree matches.")) ||
            (element.hasAttribute("aria-label") && element.getAttribute("aria-label").includes("View possible tree matches."))) {
          hasMatch = true;
          break;
        }
      }
      
      chunk.style.display = hasMatch ? "" : "none";
      if (!hasMatch) hiddenCount++;
    }
  }
  
  if (hiddenCount > 0) {
    showNotification(`✓ Filtered ${hiddenCount} of ${totalCount} records`, 'info');
  }
}

// ========================================
// EXTRACT
// ========================================
function runExtractForCurrentPage() {
  const url = location.href;
  if (url.includes("familysearch.org/ark:/")) waitForFamilySearchData();
  else if (url.includes("ancestry.com/family-tree/person/tree") || 
           url.includes("ancestryinstitution.com/family-tree/person/tree")) waitForAncestryData();
  else if (url.includes("findagrave.com/memorial/")) waitForFindAGraveData();
}

function waitForFamilySearchData() {
  window.addEventListener('focus', extractFamilySearchData);
  
  const checkForData = () => {
    const labels = document.querySelectorAll(".leftSideCss_lebwza5");
    if (labels.length > 0) {
      extractFamilySearchData();
      return true;
    }
    return false;
  };
  
  if (checkForData()) return;
  
  const observer = new MutationObserver(() => {
    if (checkForData()) observer.disconnect();
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

function extractFamilySearchData() {
  if (!settings.autoExtract) return;  // Check setting
  
  const personData = { source: "familysearch", timestamp: Date.now() };
  const normalize = (str) => str.toLowerCase().replace(/[^a-z]/g, "");
  
  document.querySelectorAll(".leftSideCss_lebwza5").forEach(label => {
    const key = normalize(label.textContent);
    const valueContainer = label.nextElementSibling;
    if (!valueContainer?.classList.contains("rightSideCss_r1y3a6mc")) return;
    
    const valueElement = valueContainer.querySelector("strong");
    if (!valueElement) return;
    
    const value = valueElement.textContent.trim();
    if (key === "name") personData.fullName = value;
    else if (key === "sex") personData.sex = value;
    else if (key === "birthdate") personData.birthDate = value;
    else if (key === "birthplace") personData.birthplace = value;
    else if (key === "deathdate") personData.deathDate = value;
  });
  
  if (personData.fullName) {
    const nameParts = personData.fullName.split(/\s+/).filter(Boolean);
    personData.firstName = nameParts[0] || "";
    personData.lastName = nameParts[nameParts.length - 1] || "";
    personData.middleName = nameParts.slice(1, -1).join(" ");
  }
  
  chrome.storage.local.set({ personData }, () => {
    if (!chrome.runtime.lastError) {
      showNotification(`✓ Saved: ${personData.fullName || "Unknown"}`, 'success');
    }
  });
}

function waitForAncestryData() {
  window.addEventListener('focus', extractAncestryData);
  
  const checkForData = () => {
    const nameElement = document.querySelector("h1.userCardTitle");
    if (nameElement && nameElement.textContent.trim() !== "") {
      extractAncestryData();
      return true;
    }
    return false;
  };
  
  if (checkForData()) return;
  
  const observer = new MutationObserver(() => {
    if (checkForData()) observer.disconnect();
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

function extractAncestryData() {
  if (!settings.autoExtract) return;  // Check setting
  
  const personData = { source: "ancestry", timestamp: Date.now() };
  const allElements = document.querySelectorAll("*");
  
  const nameElement = document.querySelector("h1.userCardTitle");
  if (nameElement) {
    const fullName = nameElement.textContent.trim();
    personData.fullName = fullName;
    
    const nameParts = fullName.split(/\s+/).filter(Boolean);
    if (nameParts.length === 1) {
      personData.firstName = nameParts[0];
      personData.lastName = "";
    } else {
      personData.lastName = nameParts[nameParts.length - 1];
      personData.firstName = nameParts.slice(0, -1).join(" ");
    }
  }
  
  const datePatterns = [
    /\b\d{1,2}\s+\w+\s+\d{4}\b/g,
    /\b\w+\s+\d{1,2},?\s+\d{4}\b/g,
    /\b\d{4}\b/g
  ];
  
  // Extract birth
  for (let el of allElements) {
    const text = el.textContent;
    if (text && (text.includes("Birth") || text.includes("Born")) && 
        !text.includes("Death") && !text.includes("Died") && text.length < 200) {
      
      for (let pattern of datePatterns) {
        const matches = text.match(pattern);
        if (matches && matches.length > 0) {
          personData.birthDate = matches[0];
          break;
        }
      }
      
      const children = Array.from(el.querySelectorAll("*"));
      for (let child of children) {
        const childText = child.textContent.trim();
        if (childText.includes(",") && childText.split(" ").length > 1 && 
            childText.length > 5 && childText.length < 100 &&
            !childText.includes("Birth") && !childText.includes("Death") && 
            !/\d/.test(childText)) {
          personData.birthplace = childText;
          break;
        }
      }
      
      if (personData.birthDate) break;
    }
  }
  
  // Extract death
  for (let el of allElements) {
    const text = el.textContent;
    if (text && (text.includes("Death") || text.includes("Died")) && 
        !text.includes("Birth") && !text.includes("Born") && text.length < 200) {
      
      for (let pattern of datePatterns) {
        const matches = text.match(pattern);
        if (matches && matches.length > 0) {
          personData.deathDate = matches[0];
          break;
        }
      }
      
      const children = Array.from(el.querySelectorAll("*"));
      for (let child of children) {
        const childText = child.textContent.trim();
        if (childText.includes(",") && childText.split(" ").length > 1 && 
            childText.length > 5 && childText.length < 100 &&
            !childText.includes("Death") && !childText.includes("Birth") && 
            !/\d/.test(childText)) {
          personData.deathplace = childText;
          break;
        }
      }
      
      if (personData.deathDate) break;
    }
  }
  
  chrome.storage.local.set({ personData }, () => {
    if (!chrome.runtime.lastError) {
      showNotification(`✓ Saved: ${personData.fullName || "Unknown"}`, 'success');
    }
  });
}

function waitForFindAGraveData() {
  window.addEventListener('focus', extractFindAGraveData);
  
  const checkForData = () => {
    const nameElement = document.querySelector("h1#bio-name");
    if (nameElement && nameElement.textContent.trim() !== "") {
      extractFindAGraveData();
      return true;
    }
    return false;
  };
  
  if (checkForData()) return;
  
  const observer = new MutationObserver(() => {
    if (checkForData()) observer.disconnect();
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

function extractFindAGraveData() {
  if (!settings.autoExtract) return;  // Check setting
  
  const personData = { source: "findagrave", timestamp: Date.now() };
  
  const nameElement = document.querySelector("h1#bio-name");
  if (nameElement) {
    const nameClone = nameElement.cloneNode(true);
    nameClone.querySelectorAll('b, span.visually-hidden').forEach(badge => badge.remove());
    
    const fullName = nameClone.textContent.trim();
    personData.fullName = fullName;
    
    const nameParts = fullName.split(/\s+/).filter(Boolean);
    if (nameParts.length === 1) {
      personData.firstName = nameParts[0];
      personData.lastName = "";
    } else {
      personData.lastName = nameParts[nameParts.length - 1];
      personData.firstName = nameParts.slice(0, -1).join(" ");
    }
  }
  
  const birthDate = document.querySelector("time#birthDateLabel");
  if (birthDate) personData.birthDate = birthDate.textContent.trim();
  
  const birthPlace = document.querySelector("div#birthLocationLabel");
  if (birthPlace) personData.birthplace = birthPlace.textContent.trim();
  
  const deathDate = document.querySelector("span#deathDateLabel");
  if (deathDate) {
    let deathText = deathDate.textContent.trim();
    personData.deathDate = deathText.replace(/\s*\(aged.*?\)\s*$/i, '');
  }
  
  const deathPlace = document.querySelector("div#deathLocationLabel");
  if (deathPlace) personData.deathplace = deathPlace.textContent.trim();
  
  chrome.storage.local.set({ personData }, () => {
    if (!chrome.runtime.lastError) {
      showNotification(`✓ Saved: ${personData.fullName || "Unknown"}`, 'success');
    }
  });
}

// ========================================
// AUTO FILL
// ========================================
function setupFormFillObserver() {
  const processedDialogs = new WeakSet();
  
  const observer = new MutationObserver((mutations) => {
    for (let mutation of mutations) {
      for (let node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        
        if (node.getAttribute && node.getAttribute('role') === 'dialog') {
          if (processedDialogs.has(node)) continue;
          processedDialogs.add(node);
          
          setTimeout(() => {
            const hasFirstName = node.querySelector('input[data-testid="first-name"]');
            const hasLastName = node.querySelector('input[data-testid="last-name"]');
            
            if (hasFirstName && hasLastName) {
              console.log("✅ Add Person popup detected");
              waitForFormToLoad(node);
            }
          }, 500);
        }
        
        if (node.querySelectorAll) {
          const dialogs = node.querySelectorAll('[role="dialog"]');
          dialogs.forEach(dialog => {
            if (processedDialogs.has(dialog)) return;
            processedDialogs.add(dialog);
            
            setTimeout(() => {
              const hasFirstName = dialog.querySelector('input[data-testid="first-name"]');
              const hasLastName = dialog.querySelector('input[data-testid="last-name"]');
              
              if (hasFirstName && hasLastName) {
                console.log("✅ Add Person popup detected");
                waitForFormToLoad(dialog);
              }
            }, 500);
          });
        }
      }
    }
  });
  
  observer.observe(document.body, { childList: true, subtree: true });
}

function waitForFormToLoad(dialogElement) {
  const checkFormReady = () => {
    const firstName = dialogElement.querySelector('input[data-testid="first-name"]');
    const lastName = dialogElement.querySelector('input[data-testid="last-name"]');
    const birthDate = dialogElement.querySelector('input[name="birthDate"]');
    return firstName && lastName && birthDate;
  };
  
  if (checkFormReady()) {
    fillPersonForm();
    return;
  }
  
  let attempts = 0;
  const formObserver = new MutationObserver(() => {
    if (checkFormReady()) {
      formObserver.disconnect();
      fillPersonForm();
    }
  });
  
  formObserver.observe(dialogElement, { childList: true, subtree: true });
  
  const checkInterval = setInterval(() => {
    attempts++;
    if (checkFormReady()) {
      clearInterval(checkInterval);
      formObserver.disconnect();
      fillPersonForm();
    } else if (attempts >= 30) {
      clearInterval(checkInterval);
      formObserver.disconnect();
      fillPersonForm();
    }
  }, 100);
}

function fillPersonForm() {
  try {
    chrome.storage.local.get(['personData'], (result) => {
      if (chrome.runtime.lastError) {
        console.error("Storage error - extension may have reloaded. Please refresh the page.");
        return;
      }
      
      if (!result.personData) {
        showNotification("⚠️ No person data found", 'warning');
        return;
      }
      
      fillFormWithData(result.personData);
    });
  } catch (error) {
    console.error("Extension context invalidated - please refresh the page");
  }
}

function fillFormWithData(personData) {
  if (!settings.autoFill) return;  // Check setting
  
  const firstNameField = document.querySelector("input[data-testid='first-name']");
  const lastNameField = document.querySelector("input[data-testid='last-name']");
  
  if (!firstNameField || !lastNameField) {
    showNotification("⚠️ Form fields not found", 'warning');
    return;
  }
  
  if (!personData.firstName || !personData.lastName) {
    const nameParts = (personData.fullName || "").trim().split(/\s+/);
    personData.lastName = nameParts.length > 1 ? nameParts.pop() : "";
    personData.firstName = nameParts.join(" ");
  }
  
  const firstNameWithMiddle = (personData.firstName || "") + 
                              (personData.middleName ? " " + personData.middleName : "");

  const setInput = (element, value) => {
    if (!element) return;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    element.focus();
    setter.call(element, value);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  };

  const setDate = (fieldName, value) => new Promise(resolve => {
    if (!value) {
      resolve();
      return;
    }
    
    const input = document.querySelector(`input[name='${fieldName}']`);
    if (!input) {
      resolve();
      return;
    }
    
    input.scrollIntoView({ block: "center" });
    input.focus();
    
    setTimeout(() => {
      setInput(input, value);
      
      setTimeout(() => {
        input.value += "a";
        input.dispatchEvent(new Event('input', { bubbles: true }));
        
        setTimeout(() => {
          input.value = value;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          
          let autocompleteAttempts = 0;
          const checkForAutocomplete = setInterval(() => {
            const options = Array.from(document.querySelectorAll('[role="option"], [data-testid*="standardized-date"]'));
            
            if (options.length > 1) {
              options[1].click();
              clearInterval(checkForAutocomplete);
              setTimeout(resolve, TIMING.AUTOCOMPLETE_CLICK_DELAY);
            } else if (options[0] && autocompleteAttempts > 5) {
              options[0].click();
              clearInterval(checkForAutocomplete);
              setTimeout(resolve, TIMING.AUTOCOMPLETE_CLICK_DELAY);
            }
            
            if (++autocompleteAttempts > TIMING.AUTOCOMPLETE_TIMEOUT) {
              clearInterval(checkForAutocomplete);
              resolve();
            }
          }, TIMING.AUTOCOMPLETE_CHECK);
        }, TIMING.DATE_TRIGGER_DELAY);
      }, TIMING.DATE_TRIGGER_DELAY);
    }, TIMING.DATE_FOCUS_DELAY);
  });

  Promise.resolve()
    .then(() => {
      setInput(firstNameField, firstNameWithMiddle);
      return new Promise(resolve => setTimeout(resolve, TIMING.FIELD_DELAY));
    })
    .then(() => {
      setInput(lastNameField, personData.lastName || "");
      return new Promise(resolve => setTimeout(resolve, TIMING.FIELD_DELAY));
    })
    .then(() => {
      if (personData.sex) {
        const sex = personData.sex.toLowerCase() === "male" ? "male" : "female";
        document.querySelectorAll(".radioCss_rw3ic9v").forEach(radio => {
          if (radio.value.toLowerCase() === sex) radio.click();
        });
      }
      return new Promise(resolve => setTimeout(resolve, TIMING.FIELD_DELAY));
    })
    .then(() => {
      document.querySelectorAll(".radioCss_rw3ic9v").forEach(radio => {
        if (radio.value === "deceased") radio.click();
      });
      return new Promise(resolve => setTimeout(resolve, TIMING.FIELD_DELAY));
    })
    .then(() => setDate("birthDate", personData.birthDate))
    .then(() => setDate("deathDate", personData.deathDate))
    .then(() => {
      setInput(document.querySelector("input[name='birthPlace']"), personData.birthplace || "");
      return new Promise(resolve => setTimeout(resolve, TIMING.FIELD_DELAY));
    })
    .then(() => {
      setInput(document.querySelector("input[name='deathPlace']"), personData.deathplace || "");
      return new Promise(resolve => setTimeout(resolve, TIMING.FIELD_DELAY));
    })
    .then(() => {
      showNotification("✓ Form filled successfully!", 'success');
    });
}