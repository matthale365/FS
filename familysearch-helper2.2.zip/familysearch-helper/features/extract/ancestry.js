// features/extract/ancestry.js
// Reads a person page in an Ancestry family tree (ancestry.com and the
// family-history-center version, ancestryinstitution.com).
//
// - Name, birth and death come from the person card at the top of the page.
// - Sex comes from the "Gender" fact card further down.
//
// Ancestry changes the web address before the next person's details load, so
// for a moment the old person's details are still showing, and the name and
// the Gender card can switch over at different times. To avoid mixing two
// people up, this only saves once:
//   - the details are different from the person it read just before, and
//   - nothing (name, dates, gender) has changed for a full second.

FSH.extract.site = {
  name: 'ancestry',

  // How long to wait for the Gender card before saving without it.
  GENDER_WAIT_MS: 3000,
  // How long everything must stay the same before saving.
  STEADY_MS: 1000,

  lastId: null,
  lastSignature: null,
  firstSeen: {}, // record id -> when we first saw it
  pending: '',   // what the page showed at the last check
  pendingSince: 0,

  // A person page is any Ancestry page showing the person card (name with
  // Birth/Death), whatever its web address looks like.
  isRecordPage() {
    return document.querySelector('[data-testid="usercardcontent-element"] .userCardTitle') !== null;
  },

  // A unique id for the person: "ancestry:<tree>:<person>" when the address
  // has those numbers, otherwise the address itself (minus the tab at the end,
  // like /facts, so the same person's tabs count as one).
  recordId() {
    const path = location.pathname;
    const m = path.match(/tree\/(\d+)\/person\/(\d+)/);
    if (m) return `ancestry:${m[1]}:${m[2]}`;
    return 'ancestry:' + path.replace(/\/(facts|gallery|hints|story|lifestory|records)\/?$/i, '');
  },

  read() {
    const card = document.querySelector('[data-testid="usercardcontent-element"]');
    const title = card && card.querySelector('.userCardTitle');
    if (!title) return null;

    const id = this.recordId();
    if (!this.firstSeen[id]) this.firstSeen[id] = Date.now();

    const raw = {
      ...this.readName(title.textContent),
      ...this.readEvent(card, 'birth'),
      ...this.readEvent(card, 'death')
    };

    // Still showing the previous person's details? Wait for the new ones.
    const signature = JSON.stringify(raw);
    if (id !== this.lastId && signature === this.lastSignature) return null;

    // Sex: give the Gender card a moment to load, then go without it.
    const sex = this.readGender();
    if (!sex && Date.now() - this.firstSeen[id] < this.GENDER_WAIT_MS) return null;
    raw.sex = sex;

    // Wait until nothing on the page has changed for STEADY_MS.
    const everything = id + signature + sex;
    if (everything !== this.pending) {
      this.pending = everything;
      this.pendingSince = Date.now();
      return null;
    }
    if (Date.now() - this.pendingSince < this.STEADY_MS) return null;

    this.lastId = id;
    this.lastSignature = signature;
    return raw;
  },

  readName(text) {
    // Drop stray punctuation, e.g. "Bodil Olsdat:" -> "Bodil Olsdat".
    const name = text.replace(/\s+/g, ' ').replace(/[\s:;,.]+$/, '').trim();
    // A single name on Ancestry (e.g. "Bridges") is usually a surname with
    // the given name unknown, so it goes in the last name field.
    if (name && !name.includes(' ')) return { given: '', surname: name };
    return { fullName: name };
  },

  // Finds the "Birth:" or "Death:" line and returns its date and place.
  readEvent(card, type) {
    const result = { [`${type}Date`]: '', [`${type}Place`]: '' };
    const label = Array.from(card.querySelectorAll('.userCardEvent'))
      .find((el) => el.textContent.trim().toLowerCase().replace(':', '') === type);
    const line = label && label.closest('p');
    if (!line) return result;

    const text = (selector) => {
      const el = line.querySelector(selector);
      const value = el ? el.textContent.replace(/\s+/g, ' ').trim() : '';
      return /^unknown$/i.test(value) ? '' : value;
    };
    result[`${type}Date`] = text('.dateDetail');
    result[`${type}Place`] = text('.placeDetail');
    return result;
  },

  readGender() {
    const heading = Array.from(document.querySelectorAll('.LifeEvent .userCardTitle'))
      .find((el) => el.textContent.trim().toLowerCase() === 'gender');
    const value = heading && heading.closest('.userCardContent').querySelector('.userCardSubTitle');
    return value ? value.textContent.trim() : '';
  }
};