// background.js
// Keeps the list of saved people. All saves go through here, one at a time,
// so opening several records at once can't make them overwrite each other.
//
// The list is kept in chrome.storage.session, which Chrome empties when the
// browser closes, so the next person at a shared computer starts fresh.

const MAX_SAVED = 4;

let queue = Promise.resolve();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'savePerson') {
    queue = queue
      .then(() => savePerson(message.person))
      .then(
        (result) => sendResponse(result),
        (err) => sendResponse({ status: 'error', error: String(err) })
      );
    return true; // tells Chrome we'll answer after the save finishes
  }

  // The "Fill from saved" button asks for the list here, because pages can't
  // read this storage directly.
  if (message.type === 'getSavedPeople') {
    chrome.storage.session.get('savedPeople').then(({ savedPeople = [] }) => sendResponse(savedPeople));
    return true;
  }
});

async function savePerson(person) {
  const { savedPeople = [] } = await chrome.storage.session.get('savedPeople');
  const alreadySaved = savedPeople.some((p) => p.id === person.id);

  // Newest goes first. If this record was already saved, it moves to the top
  // instead of being added twice. Anything past MAX_SAVED drops off the end.
  const list = [person, ...savedPeople.filter((p) => p.id !== person.id)].slice(0, MAX_SAVED);

  await chrome.storage.session.set({ savedPeople: list });
  return { status: alreadySaved ? 'updated' : 'added' };
}