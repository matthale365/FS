// page_bridge.js — no longer used.
// The Add Person button now works with direct .click() calls in content.js.